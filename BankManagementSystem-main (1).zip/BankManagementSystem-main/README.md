# Bank Management System
This is a software application that enables banking institutions to manage and organize their operations efficiently. This system includes features such as customer
and account management, transfer of money, balance checking, withdrawal of money etc. It provides a user-friendly interface for bank employees to perform
various tasks such as account opening, money transfer, keeping track of users etc.. By automating these functions, the system reduces the workload on employees,
minimizes errors, and improves the overall efficiency of the bank. Additionally, the system provides enhanced security features by encrypting the password during
login.

Team Members:

Sneha Srinivasan-PES2UG20CS342

Tejal Meda-PES2UG20CS369

Srushti V Reddy-PES2UG20CS353
